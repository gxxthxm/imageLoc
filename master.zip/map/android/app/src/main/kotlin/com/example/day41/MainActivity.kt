package com.example.day41

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
