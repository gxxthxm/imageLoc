## 1.2.11
update ios package
## 1.2.10
fix android 12 can not open camera

update PictureSelector

## 1.2.9
add maxTime for pick video
## 1.2.8
fix android filename error
## 1.2.7
fix android filename error
## 1.2.6
fix ios openCamera no cancel callback
## 1.2.5
update ZLPhotoBrowser and PictureSelector
## 1.2.4
fix
## 1.2.3
fix
## 1.2.2
delete some superfluous action
## 1.2.1
update important readme
## 1.2.0
fix android save bug
## 1.1.0
add language prop to set language

## 1.0.0
merge to null-safety
fix ios PickType.all bug

## 0.0.9
update ZLPhoto for more languages

## 0.0.8
support custom album name
fix some android bug

## 0.0.7
add ios/android save image/video to album/gallery

## 0.0.6
fix

## 0.0.5
fix android cast error

## 0.0.4
fix ios language

## 0.0.3
fix some bug

add compress & cropper
## 0.0.2
add picker & camera
## 0.0.1
Describe initial release.
