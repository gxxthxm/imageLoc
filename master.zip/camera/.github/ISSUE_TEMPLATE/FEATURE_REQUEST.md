---
name: Feature request
about: Suggest an idea for this project

---

## Environment

**Flutter version:**
**Plugin version:**  <!-- Add branch if necessary -->  
**Android version:**  <!-- If customize ROM, write which -->  
**iOS version:**
**Xcode version:**  
**Device information:**  <!-- Manufacturer and model -->

## Description

**What you'd like to happen:**

**Alternatives you've considered:** <!-- if available, else delete -->

**Images:** <!-- if available, else delete -->  
